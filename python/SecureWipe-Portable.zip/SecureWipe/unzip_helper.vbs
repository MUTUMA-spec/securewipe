' Fallback unzip helper for old Windows without PowerShell Expand-Archive
Dim fso, shell, zipFile, destDir
zipFile = WScript.Arguments(0)
destDir = WScript.Arguments(1)
Set fso   = CreateObject("Scripting.FileSystemObject")
Set shell = CreateObject("Shell.Application")
If Not fso.FolderExists(destDir) Then fso.CreateFolder(destDir)
shell.Namespace(destDir).CopyHere shell.Namespace(zipFile).Items(), 20
WScript.Echo "Done"
