╔══════════════════════════════════════════════════════╗
║              SecureWipe Desktop Tool v3.0            ║
║         Portable Edition — No Installation Needed    ║
╚══════════════════════════════════════════════════════╝

HOW TO USE
══════════
1. Double-click  SecureWipe.bat
   (First run downloads Python automatically — ~9MB, one time only)

2. Enable USB Debugging on your Android phone:
   Settings → About Phone → tap "Build Number" 7 times
   → Settings → Developer Options → USB Debugging ON

3. Connect phone via USB cable, click "Detect Android Device"

4. Tap ALLOW on the popup that appears on your phone

5. Click "START SECURE WIPE" — done!
   A wipe certificate is saved in this folder when complete.

FILES IN THIS FOLDER
════════════════════
SecureWipe.bat       ← Double-click this to start
secure_wipe_tool.py  ← Source code (inspect anytime)
adb.exe              ← Android Debug Bridge (bundled)
AdbWinApi.dll        ← ADB Windows driver
AdbWinUsbApi.dll     ← ADB USB support
python-runtime\      ← Created automatically on first run

TROUBLESHOOTING
═══════════════
• "No device found"    → Check USB Debugging is ON + tap Allow on phone
• "unauthorized"       → Tap OK on the permission popup on your phone
• Antivirus blocks it  → Add exception for this folder / adb.exe

For help: see the Guides page on our website.
