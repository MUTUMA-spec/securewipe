@echo off
setlocal EnableDelayedExpansion
title SecureWipe — Starting...
color 0A

:: ============================================================
::  SecureWipe Launcher v3.0
::  Self-contained: downloads Python automatically if needed
::  No admin rights required. Nothing gets installed globally.
:: ============================================================

set "TOOL_DIR=%~dp0"
set "PYTHON_DIR=%TOOL_DIR%python-runtime"
set "PYTHON_EXE=%PYTHON_DIR%\python.exe"
set "PYTHON_VER=3.11.9"
set "PYTHON_URL=https://www.python.org/ftp/python/%PYTHON_VER%/python-%PYTHON_VER%-embed-amd64.zip"
set "PYTHON_ZIP=%TOOL_DIR%python-embed.zip"

:: ── Check if our bundled Python already exists ──────────────
if exist "%PYTHON_EXE%" goto :run

:: ── Check if system Python exists (faster path) ─────────────
where python >nul 2>&1
if !errorlevel! == 0 (
    for /f "tokens=*" %%v in ('python --version 2^>^&1') do set "SYS_VER=%%v"
    echo  Found system: !SYS_VER!
    python -c "import tkinter" >nul 2>&1
    if !errorlevel! == 0 (
        echo  [OK] Using system Python with tkinter
        set "PYTHON_EXE=python"
        goto :run
    )
    echo  [INFO] System Python missing tkinter — fetching embedded build...
)

:: ── Download embedded Python (no installer, no admin) ────────
echo.
echo  =====================================================
echo   First-time setup: downloading Python runtime...
echo   This is a one-time download (~9 MB).
echo  =====================================================
echo.

:: Try PowerShell (Windows 10+ built-in)
powershell -Command "& {[Net.ServicePointManager]::SecurityProtocol='Tls12'; Invoke-WebRequest -Uri '%PYTHON_URL%' -OutFile '%PYTHON_ZIP%' -UseBasicParsing}" 2>nul
if exist "%PYTHON_ZIP%" goto :extract

:: Fallback: curl (Windows 10 1803+)
curl -L --silent --show-error "%PYTHON_URL%" -o "%PYTHON_ZIP%"
if exist "%PYTHON_ZIP%" goto :extract

:: Fallback: bitsadmin (older Windows)
bitsadmin /transfer "PyDownload" /download /priority FOREGROUND "%PYTHON_URL%" "%PYTHON_ZIP%" >nul 2>&1
if exist "%PYTHON_ZIP%" goto :extract

echo  [ERROR] Could not download Python runtime.
echo  Please check your internet connection, then try again.
echo.
echo  Alternatively, install Python from https://python.org
echo  (check "Add to PATH") then run SecureWipe.bat again.
pause
exit /b 1

:extract
echo  [OK] Download complete. Extracting...
mkdir "%PYTHON_DIR%" 2>nul
powershell -Command "Expand-Archive -Path '%PYTHON_ZIP%' -DestinationPath '%PYTHON_DIR%' -Force" 2>nul
if not exist "%PYTHON_EXE%" (
    :: Fallback unzip via VBScript
    cscript //nologo "%TOOL_DIR%unzip_helper.vbs" "%PYTHON_ZIP%" "%PYTHON_DIR%" 2>nul
)

if not exist "%PYTHON_EXE%" (
    echo  [ERROR] Extraction failed.
    echo  Please install Python manually from https://python.org
    pause
    exit /b 1
)

:: Enable importing from current dir (embedded Python restriction)
echo import site >> "%PYTHON_DIR%\python311._pth" 2>nul
echo %TOOL_DIR% >> "%PYTHON_DIR%\python311._pth" 2>nul

:: Clean up zip
del "%PYTHON_ZIP%" 2>nul

echo  [OK] Python runtime ready.
echo.

:run
:: ── Launch the tool ──────────────────────────────────────────
cd /d "%TOOL_DIR%"
"%PYTHON_EXE%" "%TOOL_DIR%secure_wipe_tool.py"
if errorlevel 1 (
    echo.
    echo  [ERROR] The tool crashed. Error code: !errorlevel!
    echo  Please take a screenshot and report this.
    pause
)
endlocal
